Don't Read The Comments!
======================
Don't Read The Comments! came out of an offhand remark I once made about how I often unconsciously scroll down to read comments, even though I know I'll regret it. DRTC! is intended to put an additional layer of decision between the habitual scroller and the waste of attention that awaits.
