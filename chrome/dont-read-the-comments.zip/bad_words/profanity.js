profanity_words = [
"arsehole",
"ass",
"asshole",
"bastard",
"bitch",
"cunt",
"cock",
"cocksucker",
"dick",
"fuck",
"motherfucker",
"piss",
"shit",
"suck",
"tit",
"tosser"
];